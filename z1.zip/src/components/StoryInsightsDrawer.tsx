import { motion, AnimatePresence } from 'framer-motion'
import {
  useMemo,
  useState,
  useRef,
  useEffect,
  useLayoutEffect,
} from 'react'
import {
  X,
  Info,
  Camera,
} from 'lucide-react'
import { StoryInsights, Story } from '../types'
import { BiBarChart } from "react-icons/bi";


interface Props {
  isOpen: boolean
  onClose: () => void
  insights?: StoryInsights
  isInsightsLoading?: boolean
  viewers?: string
  stories: Story[]
  activeStoryId?: string
  onSelectStory?: (id: string) => void
}

const EMPTY_INSIGHTS: StoryInsights = {
  totalViews: 0,
  reach: 0,
  impressions: 0,
  uniqueViewers: 0,
  followersReach: 0,
  nonFollowersReach: 0,
  viewsTimeline: [],
  viewers: [],
}

export default function StoryInsightsDrawer({
  isOpen,
  onClose,
  insights,
  isInsightsLoading = false,
  viewers,
  stories,
  activeStoryId,
  onSelectStory,
}: Props) {
  const [page, setPage] = useState<'insights' | 'viewers'>('insights')

  /**
   * فقط برای اولین باز شدن drawer:
   * استوری انتخاب‌شده اول فول‌اسکرین باشد و بعد برود سر جای خودش.
   */
  const [showEntryHero, setShowEntryHero] = useState(false)
  const [entryStoryId, setEntryStoryId] = useState<string | null>(null)
  const [hasPlayedOpenAnimation, setHasPlayedOpenAnimation] = useState(false)

  /**
   * فقط برای کنترل بصری thumbnailها.
   * این باعث می‌شود thumbnail فعال سریع‌تر و مستقل‌تر از parent آپدیت شود.
   */
  const [visualActiveStoryId, setVisualActiveStoryId] = useState<
    string | undefined
  >(activeStoryId || stories[0]?.id)

  const thumbnailsContainerRef = useRef<HTMLDivElement | null>(null)
  const storyRefs = useRef<Record<string, HTMLButtonElement | null>>({})

  const safeInsights: StoryInsights = insights ?? EMPTY_INSIGHTS

  const activeStory = stories.find((s) => s.id === activeStoryId)

  useEffect(() => {
    if (activeStoryId) {
      setVisualActiveStoryId(activeStoryId)
    }
  }, [activeStoryId])

  useEffect(() => {
    if (!visualActiveStoryId && stories[0]?.id) {
      setVisualActiveStoryId(stories[0].id)
    }
  }, [stories, visualActiveStoryId])

  const getStoryViews = (story?: Story) => {
    if (!story) return 0
    return Number((story as any).viewcount ?? 0)
  }
const getStoryTag = (story?: Story) => {
  if (!story) return ''

  return (
    (story as any).tag ||
    (story as any).storyTag 
  )
}

  const activeStoryViews = getStoryViews(activeStory)

  const formatCompact = (value?: number) => {
    const n = Number(value || 0)

    if (n >= 1000000) {
      return `${(n / 1000000).toFixed(n % 1000000 === 0 ? 0 : 1)}M`
    }

    if (n >= 1000) {
      return `${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}K`
    }

    return String(n)
  }

  const formatNumber = (value?: number) => {
    return Number(value || 0).toLocaleString('en-US')
  }

  const getStoryThumbnail = (story: Story) => {
    return (
      (story as any).thumbnailUrl ||
      (story as any).thumbnail ||
      (story as any).mediaUrl ||
      (story as any).file ||
      ''
    )
  }

    const getStoryViewer = (story: Story) => {
    return (
      (story as any).viewverImage ||
      ''
    )
  }

  const getStoryUsername = (story?: Story) => {
    if (!story) return 'story'

    return (
      (story as any).username ||
      (story as any).profile?.username ||
      (story as any).profileUsername ||
      'story'
    )
  }

  /**
   * سنتر کردن دقیق thumbnail فعال.
   * این روش از scrollIntoView پایدارتر است، چون position واقعی داخل container را حساب می‌کند.
   */
  const centerStoryById = (
    storyId?: string,
    behavior: ScrollBehavior = 'smooth'
  ) => {
    const id = storyId || visualActiveStoryId || activeStoryId
    if (!id) return

    const container = thumbnailsContainerRef.current
    const target = storyRefs.current[id]

    if (!container || !target) return

    const containerRect = container.getBoundingClientRect()
    const targetRect = target.getBoundingClientRect()

    const currentScrollLeft = container.scrollLeft

    const targetCenter =
      targetRect.left -
      containerRect.left +
      currentScrollLeft +
      targetRect.width / 2

    const nextScrollLeft = targetCenter - container.clientWidth / 2

    container.scrollTo({
      left: Math.max(0, nextScrollLeft),
      behavior,
    })
  }

  const handleSelectThumbnail = (storyId: string) => {
    setVisualActiveStoryId(storyId)
    onSelectStory?.(storyId)

    requestAnimationFrame(() => {
      centerStoryById(storyId, 'smooth')
    })

    window.setTimeout(() => {
      centerStoryById(storyId, 'smooth')
    }, 340)
  }

  /**
   * هنگام باز شدن drawer:
   * - hero اجرا می‌شود.
   * - thumbnail اصلی تا پایان hero داخل strip رندر نمی‌شود.
   * - بعد از حذف hero، thumbnail واقعی mount می‌شود و center می‌شود.
   */
  useEffect(() => {
    if (!isOpen) {
      setShowEntryHero(false)
      setEntryStoryId(null)
      setHasPlayedOpenAnimation(false)
      return
    }

    if (activeStoryId && !hasPlayedOpenAnimation) {
      setVisualActiveStoryId(activeStoryId)
      setEntryStoryId(activeStoryId)
      setShowEntryHero(true)
      setHasPlayedOpenAnimation(true)

      const t = window.setTimeout(() => {
        setShowEntryHero(false)

        requestAnimationFrame(() => {
          centerStoryById(activeStoryId, 'auto')

          requestAnimationFrame(() => {
            centerStoryById(activeStoryId, 'smooth')
          })
        })
      }, 520)

      return () => {
        window.clearTimeout(t)
      }
    }
  }, [isOpen, activeStoryId, hasPlayedOpenAnimation])

  /**
   * هر بار thumbnail فعال عوض شد:
   * اگر hero هنوز در حال اجراست، اسکرول نکن؛ چون thumbnail اصلی عمداً رندر نشده.
   * بعد از پایان hero، thumbnail واقعی center می‌شود.
   */
  useLayoutEffect(() => {
    if (!isOpen || !visualActiveStoryId || showEntryHero) return

    const raf = requestAnimationFrame(() => {
      centerStoryById(visualActiveStoryId, 'smooth')
    })

    const t = window.setTimeout(() => {
      centerStoryById(visualActiveStoryId, 'smooth')
    }, 340)

    return () => {
      cancelAnimationFrame(raf)
      window.clearTimeout(t)
    }
  }, [visualActiveStoryId, isOpen, showEntryHero, stories.length])

  const metrics = useMemo(() => {
    const views = Number(activeStoryViews || 0)

    const uniqueViewers = Number(Math.round(views * 0.92))
    const reach = Number(Math.round(views * 1.12))
    const impressions = Number(Math.round(views * 1.32))
    const followersReach = Number(Math.round(views * 0.98))
    const nonFollowersReach = Number(Math.round(views * 0.02))

    const shares = Math.round(views * 0.0018)
    const replies = Math.round(views * 0.0028)
    const profileVisits = Math.round(views * 0.0086)
    const stickerTaps = Math.round(views * 0.0034)
    const LinkClicks = Math.round(views * 0.0074)

    const actionsTaken = shares + replies + profileVisits + stickerTaps

    return {
      views,
      uniqueViewers,
      reach,
      impressions,
      followersReach,
      nonFollowersReach,
      shares,
      replies,
      profileVisits,
      stickerTaps,
      LinkClicks,
      actionsTaken,
    }
  }, [activeStoryViews, safeInsights])

  const entryStory =
    stories.find((s) => s.id === entryStoryId) || activeStory || stories[0]

  const entryThumb = entryStory ? getStoryThumbnail(entryStory) : ''
  const entryViewerImage = entryStory ? getStoryViewer(entryStory) : ''
  const entryViews = entryStory ? getStoryViews(entryStory) : 0

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.08 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm"
          />

          {/* Drawer */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{
              duration: 0.12,
              ease: [0.4, 0, 1, 1],
            }}
            className="fixed inset-0 z-50 overflow-hidden bg-[#050505] text-white"
          >
            <div className="flex h-full flex-col bg-[#050505]">
              {/* Top Area */}
              <div className="relative bg-[#111111]">
                {/* Header */}
                <div className="relative z-20 flex items-center justify-between px-3 pt-3 pb-3">
                  <button
                    type="button"
                    className="flex h-7 w-7 items-center justify-center rounded-full text-white active:scale-95"
                  >
                    <img src="/6.png" alt="" />
                  </button>

                  <button
                    type="button"
                    onClick={onClose}
                    className="flex h-9 w-9 items-center justify-center rounded-full text-white active:scale-95"
                  >
                    <X size={32} strokeWidth={2.1} />
                  </button>
                </div>

                {/* Entry Hero Animation */}
                <AnimatePresence>
                  {showEntryHero && entryStory && (
                    <motion.div
                      initial={{
                        opacity: 1,
                        x: '-50%',
                        y: 0,
                        left: '50%',
                        top: 0,
                        width: '100vw',
                        height: '100vh',
                        borderRadius: 0,
                        scale: 1,
                      }}
                      animate={{
                        opacity: 0,
                        x: '-50%',
                        y: 0,
                        left: '50%',
                        top: 78,
                        width: 56,
                        height: 100,
                        borderRadius: 8,
                        scale: 1,
                      }}
                      exit={{
                        opacity: 0,
                        scale: 0.98,
                      }}
                      transition={{
                        duration: 0.5,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className="pointer-events-none absolute z-30 overflow-hidden bg-black shadow-2xl"
                    >
                      {entryThumb ? (
                        <img
                          src={entryThumb}
                          alt=""
                          draggable={false}
                          className="h-full w-full select-none object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-[#050505]">
                          <Camera size={36} className="text-white" />
                        </div>
                      )}

                      <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent px-2 pb-2 pt-8">
                        <div className="flex items-center justify-center gap-1 text-xs font-semibold text-white">
                          
                  <img src="/7.png" className='w-[14px]' alt="" />
                          <span>{entryViews}</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Story Thumbnails */}
                <div className="relative px-4 pb-6">
                  <div
                    ref={thumbnailsContainerRef}
                    className="flex min-h-[135px] items-center justify-start gap-3 overflow-x-auto scrollbar-hide px-[calc(50vw-28px)]"
                  >
                    <AnimatePresence initial={false}>
                      {stories.map((story) => {
                        /**
                         * نکته اصلی:
                         * thumbnail مربوط به hero تا وقتی hero در حال اجراست
                         * اصلاً داخل strip رندر نمی‌شود.
                         * بعد از showEntryHero=false، همین thumbnail مثل بقیه mount می‌شود.
                         */
                        // if (showEntryHero && story.id === entryStoryId) {
                        //   return null
                        // }

                        const active = story.id === visualActiveStoryId
                        const thumb = getStoryThumbnail(story)
                        const storyViews = getStoryViews(story)

                        return (
                          <motion.button
                            key={story.id}
                            ref={(el) => {
                              storyRefs.current[story.id] = el
                            }}
                            type="button"
                            onClick={() => handleSelectThumbnail(story.id)}
                            initial={{
                              opacity: 0,
                              scale: 0.92,
                              width: active ? 56 : 48,
                            }}
                            animate={{
                              opacity: 1,
                              scale: 1,
                              width: active ? 56 : 48,
                            }}
                            exit={{
                              opacity: 0,
                              scale: 0.92,
                              width: 0,
                              marginRight: 0,
                            }}
                            transition={{
                              duration: 0.24,
                              ease: [0.22, 1, 0.36, 1],
                            }}
                            className="relative shrink-0 pt-4 active:scale-95"
                          >
                            <motion.div
                              initial={false}
                              animate={{
                                width: active ? 56 : 48,
                                height: active ? 100 : 84,
                                scale: active ? 1.1 : 1,
                                opacity: active ? 1 : 0.8,
                              }}
                              transition={{
                                width: {
                                  duration: 0.28,
                                  ease: [0.22, 1, 0.36, 1],
                                },
                                height: {
                                  duration: 0.28,
                                  ease: [0.22, 1, 0.36, 1],
                                },
                                scale: {
                                  duration: 0.28,
                                  ease: [0.22, 1, 0.36, 1],
                                },
                                opacity: {
                                  duration: 0.18,
                                  ease: 'easeOut',
                                },
                              }}
                              className={[
                                'relative overflow-hidden rounded-md bg-black shadow-sm will-change-transform',
                                active ? 'ring-2 ring-[#3a3a3a]' : '',
                              ].join(' ')}
                            >
                              {thumb ? (
                                <img
                                  src={thumb}
                                  alt=""
                                  draggable={false}
                                  className="h-full w-full select-none object-cover"
                                />
                              ) : (
                                <div className="flex h-full w-full items-center justify-center bg-[#050505]">
                                  <Camera size={24} className="text-white" />
                                </div>
                              )}

                              <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-1 pb-1 pt-5">
                                <div className="flex items-center justify-center gap-0.5 text-[10px] font-semibold text-white">
                                  
                  <img src="/7.png" className='w-[11px]' alt="" />
                                  <span className='text-[10px]'>{storyViews}</span>
                                </div>
                              </div>
                            </motion.div>
                          </motion.button>
                        )
                      })}
                    </AnimatePresence>

                    {/* Camera / New story placeholder */}
                    <button
                      type="button"
                      className="relative shrink-0 pt-4 active:scale-95"
                    >
                      <div className="flex h-[84px] w-[48px] items-center justify-center rounded-md bg-black ring-1 ring-white/10">
                        <Camera size={25} className="text-white" />
                      </div>
                    </button>
                  </div>

                  {/* Active pointer */}
                  <div className="absolute bottom-0 left-1/2 h-0 w-0 -translate-x-1/2 border-x-[12px] border-b-[12px] border-x-transparent border-b-[#050505]" />
                </div>
              </div>

              {/* Tabs */}
              <div className="flex h-[58px] items-center border-b border-white/10 bg-[#050505] px-3">
                <button
                  type="button"
                  onClick={() => setPage('insights')}
                  className={[
                    'relative flex h-full min-w-[58px] items-center justify-center',
                    page === 'insights' ? 'text-[#16bdf2]' : 'text-zinc-400',
                  ].join(' ')}
                >
                  <BiBarChart size={27}  />

                  {page === 'insights' && (
                    <motion.div
                      layoutId="insights-tab-indicator"
                      className="absolute bottom-0 left-0 right-0 mx-auto h-[2px] w-full rounded-full bg-[#16bdf2]"
                    />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setPage('viewers')}
                  className={[
                    'relative ml-4 flex h-full items-center gap-2 px-1',
                    page === 'viewers' ? 'text-white' : 'text-zinc-400',
                  ].join(' ')}
                >
                  <img src="/7.png" className='w-[23px]' alt="" />
                  <span className="text-[13px] font-bold">
                    {formatCompact(metrics.views)}
                  </span>

                  {page === 'viewers' && (
                    <motion.div
                      layoutId="insights-tab-indicator"
                      className="absolute bottom-0 left-0 right-0 mx-auto h-[2px] w-full rounded-full bg-white"
                    />
                  )}
                </button>

                <button
                  type="button"
                  className="ml-auto flex h-8 w-8 items-center justify-center text-white active:scale-95"
                >
                  <img src="/8.png" alt="" />
                </button>
              </div>

              {/* Pages */}
              <div className="relative min-h-0 flex-1 overflow-hidden bg-[#050505]">
                <motion.div
                  animate={{ x: page === 'insights' ? '0%' : '-50%' }}
                  transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                  className="flex h-full w-[200%]"
                >
                  {/* Insights Page */}
                  <div className="h-full w-1/2 flex-shrink-0 overflow-y-auto bg-[#050505] pb-10">
                    <AnimatePresence mode="wait">
                      {isInsightsLoading ? (
                        <motion.div
                          key="insights-skeleton"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.15 }}
                        >
                          {/* <InsightsSkeleton /> */}
                        </motion.div>
                      ) : (
                        <motion.div
                          key={`insights-${activeStoryId}`}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{
                            duration: 0.22,
                            ease: [0.22, 1, 0.36, 1],
                          }}
                        >
                          <div className="px-5 pt-5">
                            <SectionTitle title="Interactions" />

                            <div className="pt-5 text-center">
                              <div className="text-[26px] font-semibold leading-none text-white">
                                {formatNumber(metrics.actionsTaken)}
                              </div>
                              <div className="mt-2 text-[15px] font-medium text-zinc-500">
                                Actions taken from this story
                              </div>
                            </div>

                            <div className="mt-8 space-y-6">
                              <InsightRow
                                label="Shares"
                                value={metrics.shares}
                              />
                              <InsightRow
                                label="Replies"
                                value={metrics.replies}
                              />
                              <InsightRow
                                label="Profile visits"
                                value={metrics.profileVisits}
                              />
                              {activeStory.stickerTaps && (
                                
                              <InsightRow
                                label="Sticker taps"
                                value={metrics.stickerTaps}
                              />
                              )}
                              {activeStory.LinkClicks && (
                                
                              <InsightRow
                                label="Link Clicks"
                                value={metrics.LinkClicks}
                              />
                              )}

{entryStory.tag && getStoryTag(activeStory) !== undefined && (
  <InsightRow
    label={`@${getStoryTag(activeStory)}`}
    value={metrics.stickerTaps}
    muted
  />
)}


                            </div>
                          </div>

                          <Divider />

                          <div className="px-5 pt-5">
                            <SectionTitle title="Discovery" />

                            <div className="pt-7 text-center">
                              <div className="text-[28px] font-semibold leading-none text-white">
                                {formatNumber(metrics.reach)}
                              </div>
                              <div className="mt-2 text-[15px] font-medium text-zinc-500">
                                Accounts reached
                              </div>
                            </div>

                            <div className="mt-8 space-y-6">
                              <InsightRow
                                label="Impressions"
                                value={metrics.impressions}
                              />
                              <InsightRow
                                label="Followers"
                                value={metrics.followersReach}
                              />
                              <InsightRow
                                label="Non-followers"
                                value={metrics.nonFollowersReach}
                              />
                              <InsightRow
                                label="Unique viewers"
                                value={metrics.uniqueViewers}
                              />
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Viewers Page */}
                  <div className="h-full w-1/2 flex-shrink-0 overflow-y-auto bg-[#050505] pb-10">
                    <motion.div
                      key={`viewers-${activeStoryId}`}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                      className="pt-4"
                    >
                      <div className="px-4 mb-3 flex items-center justify-between">
                        <h3 className="text-[16px] font-semibold text-white">
                          Viewers
                        </h3>

                        <span className="text-[13px] font-semibold text-zinc-500">
                          {formatNumber(metrics.views)}
                        </span>
                      </div>
                      <img src={viewers} alt="" className="w-full" />
                      {/* {safeInsights.viewers.length > 0 ? (
                        <div>
                          {safeInsights.viewers.map((viewer, index) => (
                            <motion.div
                              key={viewer.id ?? index}
                              initial={{ opacity: 0, x: 18 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.02 }}
                              className="flex items-center justify-between border-b border-white/[0.06] py-3"
                            >
                              <div className="flex min-w-0 items-center gap-3">
                                <div className="h-11 w-11 shrink-0 overflow-hidden rounded-full bg-zinc-900 ring-1 ring-white/10">
                                  {viewer.avatarUrl ? (
                                    <img
                                      src={viewer.avatarUrl}
                                      alt={viewer.name}
                                      className="h-full w-full object-cover"
                                    />
                                  ) : (
                                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-zinc-800 to-zinc-950">
                                      <Users
                                        size={18}
                                        className="text-zinc-500"
                                      />
                                    </div>
                                  )}
                                </div>

                                <div className="min-w-0">
                                  <div className="truncate text-[14px] font-semibold text-white">
                                    {viewer.name}
                                  </div>
                                  <div className="truncate text-[12px] text-zinc-500">
                                    Viewed your story
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      ) : (
                        <div className="flex min-h-[280px] flex-col items-center justify-center text-center">
                          <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-zinc-900 ring-1 ring-white/10">
                            <Users size={28} className="text-zinc-500" />
                          </div>

                          <div className="text-[15px] font-semibold text-white">
                            No viewers yet
                          </div>

                          <div className="mt-1 max-w-[240px] text-[13px] leading-5 text-zinc-500">
                            Viewers from your backend will appear here.
                          </div>
                        </div>
                      )} */}
                    </motion.div>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

function SectionTitle({ title }: { title: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <h2 className="text-[19px] font-bold leading-none text-white">
        {title}
      </h2>
      <Info size={18} strokeWidth={2.2} className="text-zinc-400" />
    </div>
  )
}

function InsightRow({
  label,
  value,
  muted = false,
}: {
  label: string
  value: number
  muted?: boolean
}) {
  return (
    <div className="flex items-center justify-between">
      <span
        className={[
          'text-[16px] font-medium',
          muted ? 'text-zinc-500' : 'text-zinc-200',
        ].join(' ')}
      >
        {label}
      </span>

      <span
        className={[
          'text-[15px] font-semibold',
          muted ? 'text-zinc-500' : 'text-white',
        ].join(' ')}
      >
        {Number(value || 0).toLocaleString('en-US')}
      </span>
    </div>
  )
}

function Divider() {
  return <div className="mt-8 h-[1px] w-full bg-white/10" />
}
